package netstack

import (
	"bufio"
	"encoding/binary"
	"fmt"
	"io"
)

// MaxFrameSize bounds a single message to prevent a misbehaving peer from
// exhausting memory with a bogus length prefix.
const MaxFrameSize = 16 * 1024 * 1024 // 16 MiB

// FrameWriter writes length-prefixed frames: a 4-byte big-endian length
// followed by that many bytes of payload.
type FrameWriter struct {
	w io.Writer
}

// NewFrameWriter wraps w for framed writes.
func NewFrameWriter(w io.Writer) *FrameWriter {
	return &FrameWriter{w: w}
}

// WriteFrame writes a single length-prefixed message.
func (fw *FrameWriter) WriteFrame(payload []byte) error {
	if len(payload) > MaxFrameSize {
		return fmt.Errorf("netstack: frame too large: %d bytes (max %d)", len(payload), MaxFrameSize)
	}
	var header [4]byte
	binary.BigEndian.PutUint32(header[:], uint32(len(payload)))
	if _, err := fw.w.Write(header[:]); err != nil {
		return fmt.Errorf("netstack: write frame header: %w", err)
	}
	if _, err := fw.w.Write(payload); err != nil {
		return fmt.Errorf("netstack: write frame payload: %w", err)
	}
	return nil
}

// FrameReader reads length-prefixed frames written by FrameWriter.
type FrameReader struct {
	r *bufio.Reader
}

// NewFrameReader wraps r for framed reads.
func NewFrameReader(r io.Reader) *FrameReader {
	return &FrameReader{r: bufio.NewReader(r)}
}

// ReadFrame reads and returns the next length-prefixed message. It
// returns io.EOF when the underlying stream ends cleanly between frames.
func (fr *FrameReader) ReadFrame() ([]byte, error) {
	var header [4]byte
	if _, err := io.ReadFull(fr.r, header[:]); err != nil {
		if err == io.ErrUnexpectedEOF {
			return nil, fmt.Errorf("netstack: truncated frame header: %w", err)
		}
		return nil, err
	}

	length := binary.BigEndian.Uint32(header[:])
	if length > MaxFrameSize {
		return nil, fmt.Errorf("netstack: peer sent oversized frame: %d bytes (max %d)", length, MaxFrameSize)
	}

	payload := make([]byte, length)
	if _, err := io.ReadFull(fr.r, payload); err != nil {
		return nil, fmt.Errorf("netstack: read frame payload: %w", err)
	}
	return payload, nil
}
