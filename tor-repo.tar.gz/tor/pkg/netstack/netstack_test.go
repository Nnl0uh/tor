package netstack

import (
	"bytes"
	"context"
	"net"
	"testing"
	"time"
)

func TestServerDialerRoundTrip(t *testing.T) {
	received := make(chan string, 1)

	srv := NewServer("127.0.0.1:0", func(conn net.Conn) {
		defer conn.Close()
		fr := NewFrameReader(conn)
		payload, err := fr.ReadFrame()
		if err != nil {
			t.Errorf("server ReadFrame: %v", err)
			return
		}
		received <- string(payload)
	})

	go func() {
		if err := srv.ListenAndServe(); err != nil {
			t.Logf("ListenAndServe returned: %v", err)
		}
	}()
	defer srv.Close()

	// Wait for the listener to actually bind.
	var addr net.Addr
	for i := 0; i < 100; i++ {
		if addr = srv.Addr(); addr != nil {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if addr == nil {
		t.Fatal("server never bound a listening address")
	}

	dialer := NewDialer(DefaultDialerConfig())
	conn, err := dialer.Dial(context.Background(), addr.String())
	if err != nil {
		t.Fatalf("Dial: %v", err)
	}
	defer conn.Close()

	fw := NewFrameWriter(conn)
	if err := fw.WriteFrame([]byte("hello, silk")); err != nil {
		t.Fatalf("WriteFrame: %v", err)
	}

	select {
	case msg := <-received:
		if msg != "hello, silk" {
			t.Errorf("got %q, want %q", msg, "hello, silk")
		}
	case <-time.After(2 * time.Second):
		t.Fatal("timed out waiting for server to receive frame")
	}
}

func TestFrameRoundTrip(t *testing.T) {
	var buf bytes.Buffer
	fw := NewFrameWriter(&buf)
	fr := NewFrameReader(&buf)

	messages := [][]byte{
		[]byte("first"),
		[]byte(""),
		[]byte("a longer message with several words in it"),
	}

	for _, m := range messages {
		if err := fw.WriteFrame(m); err != nil {
			t.Fatalf("WriteFrame(%q): %v", m, err)
		}
	}

	for _, want := range messages {
		got, err := fr.ReadFrame()
		if err != nil {
			t.Fatalf("ReadFrame: %v", err)
		}
		if !bytes.Equal(got, want) {
			t.Errorf("got %q, want %q", got, want)
		}
	}
}

func TestFrameOversized(t *testing.T) {
	var buf bytes.Buffer
	fw := NewFrameWriter(&buf)
	oversized := make([]byte, MaxFrameSize+1)
	if err := fw.WriteFrame(oversized); err == nil {
		t.Fatal("expected error writing oversized frame, got nil")
	}
}

func TestDialerFailsOnUnreachable(t *testing.T) {
	cfg := DialerConfig{
		MaxAttempts:    2,
		InitialBackoff: 10 * time.Millisecond,
		MaxBackoff:     20 * time.Millisecond,
		DialTimeout:    200 * time.Millisecond,
	}
	dialer := NewDialer(cfg)

	// Port 0 with an explicit unreachable address; using a reserved
	// TEST-NET-1 address (RFC 5737) which should not route.
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()

	_, err := dialer.Dial(ctx, "192.0.2.1:9")
	if err == nil {
		t.Fatal("expected dial error for unreachable address, got nil")
	}
}

func TestPoolReusesConnection(t *testing.T) {
	srv := NewServer("127.0.0.1:0", func(conn net.Conn) {
		// Echo server: keep connection open, echo one frame.
		defer conn.Close()
		fr := NewFrameReader(conn)
		fw := NewFrameWriter(conn)
		for {
			payload, err := fr.ReadFrame()
			if err != nil {
				return
			}
			_ = fw.WriteFrame(payload)
		}
	})
	go srv.ListenAndServe()
	defer srv.Close()

	var addr net.Addr
	for i := 0; i < 100; i++ {
		if addr = srv.Addr(); addr != nil {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if addr == nil {
		t.Fatal("server never bound")
	}

	pool := NewPool(NewDialer(DefaultDialerConfig()), 2)
	defer pool.Close()

	ctx := context.Background()
	conn1, err := pool.Get(ctx, addr.String())
	if err != nil {
		t.Fatalf("Get: %v", err)
	}
	pool.Put(addr.String(), conn1)

	conn2, err := pool.Get(ctx, addr.String())
	if err != nil {
		t.Fatalf("Get: %v", err)
	}
	if conn1 != conn2 {
		t.Error("expected pool to reuse the idle connection")
	}
	pool.Put(addr.String(), conn2)
}
