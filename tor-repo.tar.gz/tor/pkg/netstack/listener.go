package netstack

import (
	"fmt"
	"log"
	"net"
	"sync"
)

// ConnHandler processes a single accepted connection. Implementations
// should close conn when finished.
type ConnHandler func(conn net.Conn)

// Server wraps net.Listener with graceful shutdown and per-connection
// panic isolation, so one bad handler can't take down the process.
type Server struct {
	addr     string
	handler  ConnHandler
	listener net.Listener

	mu       sync.Mutex
	wg       sync.WaitGroup
	closed   bool
	closeErr error
}

// NewServer builds a Server bound to addr. The handler is invoked in its
// own goroutine for every accepted connection.
func NewServer(addr string, handler ConnHandler) *Server {
	return &Server{addr: addr, handler: handler}
}

// ListenAndServe binds the listening socket and blocks, accepting
// connections until Close is called.
func (s *Server) ListenAndServe() error {
	ln, err := net.Listen("tcp", s.addr)
	if err != nil {
		return fmt.Errorf("netstack: listen %s: %w", s.addr, err)
	}

	s.mu.Lock()
	s.listener = ln
	s.mu.Unlock()

	for {
		conn, err := ln.Accept()
		if err != nil {
			s.mu.Lock()
			closed := s.closed
			s.mu.Unlock()
			if closed {
				s.wg.Wait()
				return nil
			}
			return fmt.Errorf("netstack: accept: %w", err)
		}

		s.wg.Add(1)
		go func() {
			defer s.wg.Done()
			defer func() {
				if r := recover(); r != nil {
					log.Printf("netstack: recovered handler panic: %v", r)
					conn.Close()
				}
			}()
			s.handler(conn)
		}()
	}
}

// Close stops accepting new connections. In-flight handlers are allowed
// to finish; ListenAndServe returns once they do.
func (s *Server) Close() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed {
		return s.closeErr
	}
	s.closed = true
	if s.listener != nil {
		s.closeErr = s.listener.Close()
	}
	return s.closeErr
}

// Addr returns the resolved listening address. Only valid after
// ListenAndServe has started.
func (s *Server) Addr() net.Addr {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.listener == nil {
		return nil
	}
	return s.listener.Addr()
}
