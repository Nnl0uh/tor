package netstack

import (
	"context"
	"net"
	"sync"
)

// Pool maintains a bounded set of idle, reusable TCP connections per
// address, avoiding repeated TCP handshake + backoff cost for
// short-lived requests to the same peer.
type Pool struct {
	dialer  *Dialer
	maxIdle int

	mu    sync.Mutex
	idle  map[string][]net.Conn
	total map[string]int
}

// NewPool builds a Pool that dials with the given Dialer and keeps up to
// maxIdle idle connections per address.
func NewPool(dialer *Dialer, maxIdle int) *Pool {
	if maxIdle <= 0 {
		maxIdle = 1
	}
	return &Pool{
		dialer:  dialer,
		maxIdle: maxIdle,
		idle:    make(map[string][]net.Conn),
		total:   make(map[string]int),
	}
}

// Get returns an idle connection to addr if one is available, otherwise
// dials a new one.
func (p *Pool) Get(ctx context.Context, addr string) (net.Conn, error) {
	p.mu.Lock()
	if conns := p.idle[addr]; len(conns) > 0 {
		conn := conns[len(conns)-1]
		p.idle[addr] = conns[:len(conns)-1]
		p.mu.Unlock()
		return conn, nil
	}
	p.mu.Unlock()

	conn, err := p.dialer.Dial(ctx, addr)
	if err != nil {
		return nil, err
	}
	p.mu.Lock()
	p.total[addr]++
	p.mu.Unlock()
	return conn, nil
}

// Put returns conn to the idle pool for reuse, or closes it if the pool
// for that address is already full.
func (p *Pool) Put(addr string, conn net.Conn) {
	p.mu.Lock()
	defer p.mu.Unlock()

	if len(p.idle[addr]) >= p.maxIdle {
		conn.Close()
		p.total[addr]--
		return
	}
	p.idle[addr] = append(p.idle[addr], conn)
}

// Close closes every idle connection currently held by the pool.
func (p *Pool) Close() error {
	p.mu.Lock()
	defer p.mu.Unlock()

	var firstErr error
	for addr, conns := range p.idle {
		for _, c := range conns {
			if err := c.Close(); err != nil && firstErr == nil {
				firstErr = err
			}
		}
		delete(p.idle, addr)
	}
	return firstErr
}
