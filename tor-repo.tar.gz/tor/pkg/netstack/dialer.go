// Package netstack provides a small, dependency-free TCP/IP networking
// toolkit: a resilient dialer, a supervised listener, and a lightweight
// length-prefixed framing protocol for streaming messages over TCP.
package netstack

import (
	"context"
	"fmt"
	"net"
	"time"
)

// DialerConfig controls retry/backoff behavior for outbound TCP connections.
type DialerConfig struct {
	// MaxAttempts is the number of dial attempts before giving up.
	MaxAttempts int
	// InitialBackoff is the wait time before the first retry.
	InitialBackoff time.Duration
	// MaxBackoff caps the exponential backoff growth.
	MaxBackoff time.Duration
	// DialTimeout bounds each individual dial attempt.
	DialTimeout time.Duration
}

// DefaultDialerConfig returns sane defaults for LAN/WAN TCP connections.
func DefaultDialerConfig() DialerConfig {
	return DialerConfig{
		MaxAttempts:    5,
		InitialBackoff: 100 * time.Millisecond,
		MaxBackoff:     5 * time.Second,
		DialTimeout:    3 * time.Second,
	}
}

// Dialer establishes outbound TCP connections with exponential backoff.
type Dialer struct {
	cfg DialerConfig
}

// NewDialer builds a Dialer with the given configuration.
func NewDialer(cfg DialerConfig) *Dialer {
	if cfg.MaxAttempts <= 0 {
		cfg.MaxAttempts = 1
	}
	if cfg.InitialBackoff <= 0 {
		cfg.InitialBackoff = 100 * time.Millisecond
	}
	if cfg.MaxBackoff <= 0 {
		cfg.MaxBackoff = 5 * time.Second
	}
	if cfg.DialTimeout <= 0 {
		cfg.DialTimeout = 3 * time.Second
	}
	return &Dialer{cfg: cfg}
}

// Dial connects to addr over TCP, retrying with exponential backoff on
// failure until MaxAttempts is exhausted or ctx is canceled.
func (d *Dialer) Dial(ctx context.Context, addr string) (net.Conn, error) {
	var lastErr error
	backoff := d.cfg.InitialBackoff

	for attempt := 1; attempt <= d.cfg.MaxAttempts; attempt++ {
		dialCtx, cancel := context.WithTimeout(ctx, d.cfg.DialTimeout)
		conn, err := (&net.Dialer{}).DialContext(dialCtx, "tcp", addr)
		cancel()

		if err == nil {
			return conn, nil
		}
		lastErr = err

		if attempt == d.cfg.MaxAttempts {
			break
		}

		select {
		case <-ctx.Done():
			return nil, fmt.Errorf("netstack: dial canceled: %w", ctx.Err())
		case <-time.After(backoff):
		}

		backoff *= 2
		if backoff > d.cfg.MaxBackoff {
			backoff = d.cfg.MaxBackoff
		}
	}

	return nil, fmt.Errorf("netstack: dial %s failed after %d attempts: %w", addr, d.cfg.MaxAttempts, lastErr)
}
