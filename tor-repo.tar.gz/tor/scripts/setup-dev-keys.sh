#!/usr/bin/env bash
# setup-dev-keys.sh
#
# Generates a local SSH key (for git push/pull over SSH) and a local GPG
# key (for signed commits), then configures this repo to use them.
#
# Nothing here talks to any API or requires a token. You paste the two
# printed public keys into GitHub's web UI by hand:
#   SSH key  -> https://github.com/settings/keys
#   GPG key  -> https://github.com/settings/keys  (GPG keys tab)
#
# Safe to re-run: it skips generation if a key already exists.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GIT_NAME="${GIT_NAME:-$(git config --get user.name || echo "Your Name")}"
GIT_EMAIL="${GIT_EMAIL:-$(git config --get user.email || echo "you@example.com")}"
SSH_KEY_PATH="${SSH_KEY_PATH:-$HOME/.ssh/id_ed25519_$(basename "$REPO_ROOT")}"

echo "== 1/3: SSH key for git push/pull =="
if [ -f "$SSH_KEY_PATH" ]; then
  echo "SSH key already exists at $SSH_KEY_PATH, skipping generation."
else
  ssh-keygen -t ed25519 -C "$GIT_EMAIL" -f "$SSH_KEY_PATH" -N ""
  echo "Generated $SSH_KEY_PATH"
fi
echo
echo "Public key (add this at https://github.com/settings/keys):"
cat "${SSH_KEY_PATH}.pub"
echo

cat >> "$HOME/.ssh/config" <<EOF

Host github.com-$(basename "$REPO_ROOT")
  HostName github.com
  User git
  IdentityFile $SSH_KEY_PATH
  IdentitiesOnly yes
EOF
echo "Added SSH host alias 'github.com-$(basename "$REPO_ROOT")' to ~/.ssh/config"
echo "Use it as: git remote set-url origin git@github.com-$(basename "$REPO_ROOT"):ORG/REPO.git"
echo

echo "== 2/3: GPG key for signed commits =="
EXISTING_KEY="$(gpg --list-secret-keys --with-colons "$GIT_EMAIL" 2>/dev/null | awk -F: '/^sec/{print $5; exit}')"
if [ -n "${EXISTING_KEY:-}" ]; then
  echo "GPG key already exists for $GIT_EMAIL, skipping generation."
  KEY_ID="$EXISTING_KEY"
else
  gpg --batch --pinentry-mode loopback --passphrase '' --quick-generate-key \
    "$GIT_NAME <$GIT_EMAIL>" ed25519 sign 2y
  KEY_ID="$(gpg --list-secret-keys --with-colons "$GIT_EMAIL" | awk -F: '/^sec/{print $5; exit}')"
  echo "Generated GPG key $KEY_ID"
fi
echo
echo "Public key (add this at https://github.com/settings/keys, GPG Keys tab):"
gpg --armor --export "$KEY_ID"
echo

echo "== 3/3: Configuring this repo to sign commits =="
cd "$REPO_ROOT"
git config user.name "$GIT_NAME"
git config user.email "$GIT_EMAIL"
git config user.signingkey "$KEY_ID"
git config commit.gpgsign true
git config tag.gpgsign true

echo
echo "Done. Local git config for this repo now signs commits with $KEY_ID."
echo "Remember to add BOTH public keys to your GitHub account before pushing."
