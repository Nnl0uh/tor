# tor

A small, dependency-free TCP/IP networking library for Go: a resilient
dialer with exponential backoff, a supervised listener with panic
isolation, a length-prefixed framing protocol for streaming messages
over TCP, and a lightweight connection pool.

Package: `github.com/p9xr/tor/pkg/netstack`

## Why

Most projects don't need a full networking framework — they need a
dialer that retries sanely, a listener that doesn't die when one
handler panics, and a way to send discrete messages over a stream
socket without rolling it by hand every time. That's what this is.

## Quick start

```go
import "github.com/p9xr/tor/pkg/netstack"

srv := netstack.NewServer("127.0.0.1:9797", func(conn net.Conn) {
    defer conn.Close()
    fr := netstack.NewFrameReader(conn)
    msg, err := fr.ReadFrame()
    // ...
})
go srv.ListenAndServe()
defer srv.Close()

dialer := netstack.NewDialer(netstack.DefaultDialerConfig())
conn, err := dialer.Dial(ctx, "127.0.0.1:9797")
fw := netstack.NewFrameWriter(conn)
fw.WriteFrame([]byte("hello"))
```

## Development

```sh
make ci      # fmt + vet + build + test, exactly what CI runs, fully local
make act     # run the actual GitHub Actions workflow locally via Docker
```

### One-time setup: SSH + GPG for pushing signed commits

```sh
./scripts/setup-dev-keys.sh
```

Generates a local SSH key (for `git push` over SSH) and a local GPG key
(for signed commits), and configures this repo to sign commits. It only
talks to your local `ssh-keygen`/`gpg` binaries — no API calls. You then
paste the two printed public keys into GitHub's web UI by hand.

## CI/CD

`.github/workflows/ci.yml` runs on every push/PR: `go vet`, `go build`,
`go test -race` with coverage, and a `gofmt` check. It requires no
secrets and no API tokens — everything it uses (`actions/checkout`,
`actions/setup-go`, `actions/upload-artifact`) operates on the public
repo contents already available to the runner.

The same workflow can be run locally with
[`act`](https://github.com/nektos/act) via `make act`, so you get
identical results before ever pushing.

## Testing

```sh
go test ./... -race -v
```
